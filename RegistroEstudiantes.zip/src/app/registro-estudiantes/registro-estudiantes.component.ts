import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-estudiantes',
  templateUrl: './registro-estudiantes.component.html',
  styleUrls: ['./registro-estudiantes.component.scss']
})
export class RegistroEstudiantesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
